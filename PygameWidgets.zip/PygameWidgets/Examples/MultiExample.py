from PygameWidgets import Cursor,Btn,Clock,Colors
import pygame
pygame.init()
screen=pygame.display.set_mode((500,500),pygame.RESIZABLE)
Button=Btn.Normal_Btn(screen,text='Click',xy=(100,100),size=50)
#ActiveBtn=Btn.Active_Btn(screen,text='Hello',Colors=((255,0,0),(0,255,0),(0,0,255),(0,0,0),(255,255,255)))
ActiveBtn=Btn.Active_Btn(screen,text='Hello',Colors=(Colors.Red,Colors.Green,Colors.Blue,Colors.Black,Colors.White))
run=True
size=5
C=Cursor.Rect_Cursor(screen,Width=size,Height=size)
FPS=200
Clock=Clock.Clock(FPS)
Clock.Set_Up_Clock()
while run:
    Clock.Set_FPS()
    screen.fill(Colors.Black)
    C.Draw()
    Button.Draw()
    ActiveBtn.Draw()
    mousepos=(C.x,C.y)
    pygame.display.update()
    for e in pygame.event.get():
        if e.type==pygame.QUIT:
            run=False
        YN=Button.Detect(mousepos,e)
        YN1=ActiveBtn.Detect(mousepos,e)
        if YN:
            size+=5
            C=Cursor.Rect_Cursor(screen,Width=size,Height=size)
            Clock.Set_Delay(TIME=1)
        if YN1:
            #print('Custom!')
            size+=10
            C=Cursor.Rect_Cursor(screen,Width=size,Height=size)
            Clock.Set_Delay(TIME=1)
        
pygame.quit()
