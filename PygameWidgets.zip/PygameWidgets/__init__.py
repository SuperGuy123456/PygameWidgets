from datetime import date

today = date.today()

print("Current date =", today,'\nPygameWidgets Active!\nhttps://PygameWidgetsWebsite.superguy123456.repl.co')
